const claveApi = '4b093a6d61a342c590011229262409';
const idioma = 'es';
const inpCiudad = document.getElementById('input-ciudad');
const contenedorClima = document.getElementById('clima-contenedor');

async function obtenerClima() {

    const ciudad = inpCiudad.value.trim();

    if (!ciudad) {
        alert('Por favor, ingresa una ciudad');
        return;
    }

    const apiClimaActual = `https://api.weatherapi.com/v1/current.json?q=${encodeURIComponent(ciudad)}&lang=${idioma}&key=${claveApi}`;

    try {
        const response = await fetch(apiClimaActual);
        const data = await response.json();

        if (data.error) {
            contenedorClima.style.display = 'none';
            if (data.error.code === 1006) {
                alert('No se encontró la ciudad. Revisa el nombre e inténtalo de nuevo.');
            } else {
                alert('No se pudo obtener el clima: ' + data.error.message);
            }
            return;
        }

        mostrarClima(data);
    } catch (error) {
        alert('No se pudo conectar con el servicio del clima. Revisa tu conexión a internet.');
    }
}

function mostrarClima(data) {
    document.querySelector('.clima-icono').src = 'https:' + data.current.condition.icon;
    document.querySelector('.clima-texto').innerHTML = data.current.condition.text;
    document.querySelector('.temp').innerHTML = data.current.temp_c + 'ºC';
    document.querySelector('.ciudad').innerHTML = data.location.name;
    document.querySelector('.humedad').innerHTML = data.current.humidity + '%';
    document.querySelector('.viento').innerHTML = data.current.wind_kph + ' km/h';

    contenedorClima.style.display = 'block';
}

inpCiudad.addEventListener('keydown', function (evento) {
    if (evento.key === 'Enter') {
        obtenerClima();
    }
});
