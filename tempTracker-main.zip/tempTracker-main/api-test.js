const claveApi = '4b093a6d61a342c590011229262409';
const idioma = 'es';
const ciudad = 'Huancayo';

const apiClimaActual = `https://api.weatherapi.com/v1/current.json?q=${encodeURIComponent(ciudad)}&lang=${idioma}&key=${claveApi}`;

async function probarApi() {
    const response = await fetch(apiClimaActual);
    const data = await response.json();

    console.log(data);
}

probarApi();